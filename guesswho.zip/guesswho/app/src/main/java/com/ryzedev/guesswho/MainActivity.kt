package com.ryzedev.guesswho

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.ryzedev.guesswho.databinding.ActivityMainBinding

private const val TAG = "MainActivity"



class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val guessPokemonView: GuessPokemonView by viewModels()

    private val answersLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        // Handle the result
        if (result.resultCode == Activity.RESULT_OK) {
            guessPokemonView.answer = result.data?.getBooleanExtra(EXTRA_ANSWER_SHOWN, false) ?: false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "OnCreate(Bundle?) called")
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Log.d(TAG, "Got a guessPokemonView: $guessPokemonView")


        binding.submit.setOnClickListener {
            lateinit var checkText: EditText
            checkText = findViewById(R.id.placeholder)
            val correctAnswer = guessPokemonView.currentQuestionAnswer
            if (checkText.text.toString() == correctAnswer) {
                checkAnswer(checkText.text.toString())
                guessPokemonView.moveToNext()
                updateQuestion()
            } else {
                Toast.makeText(this, R.string.incorrect_toast, Toast.LENGTH_SHORT).show()
            }


        }

        binding.answers.setOnClickListener {
            val answerIsCorrect = guessPokemonView.currentQuestionAnswer
            val intent = AnswersSheet.newIntent(this@MainActivity, answerIsCorrect = true)
            answersLauncher.launch(intent)
        }

//        binding.next.setOnClickListener {
//            guessPokemonView.moveToNext()
//            updateQuestion()
//        }



        updateQuestion()

    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart() called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume() called")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause() called")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop() called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy called")
    }

    private fun updateQuestion() {
        val questionTextResId = guessPokemonView.currentQuestionTextId

        lateinit var imageView: ImageView
        imageView = findViewById(R.id.image)

        lateinit var checkText: EditText
        checkText = findViewById(R.id.placeholder)
        checkText.setText("")

        if ( questionTextResId == 0 ) {
            imageView.setImageResource(R.drawable._01)
        } else if ( questionTextResId == 1 ) {
                imageView.setImageResource(R.drawable.charmander)
        } else if ( questionTextResId == 2 ) {
                imageView.setImageResource(R.drawable.squirtle)
        } else if ( questionTextResId == 3 ) {
                imageView.setImageResource(R.drawable.ditto)
        } else {
                imageView.setImageResource(R.drawable.gengar)
        }



    }

    private fun checkAnswer(userAnswer: String) {
        val correctAnswer = guessPokemonView.currentQuestionAnswer

        val messageResId = when {
            guessPokemonView.answer ->R.string.judgment_toast
            userAnswer == correctAnswer -> R.string.correct_toast
            else -> R.string.incorrect_toast
        }

        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show()
    }

}


