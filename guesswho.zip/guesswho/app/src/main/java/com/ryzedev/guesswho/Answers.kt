package com.ryzedev.guesswho

import androidx.annotation.StringRes

data class Answers(@StringRes val textResId: Int, val answer: String)
