package com.ryzedev.guesswho

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel

private const val TAG = "GuessPokemonView"

const val CURRENT_INDEX_KEY = "CURRENT_INDEX_KEY"

const val ANSWER_KEY = "ANSWER_KEY"

class GuessPokemonView(private val savedStateHandle: SavedStateHandle) : ViewModel() {


     val answersBank = listOf(
        Answers(R.string.bulbasaur, "Bulbasaur"),
        Answers(R.string.charmander, "Charmander"),
        Answers(R.string.squirtle, "Squirtle"),
        Answers(R.string.ditto, "Ditto"),
        Answers(R.string.gengar, "Gengar")
    )

    var answer: Boolean get() = savedStateHandle.get(ANSWER_KEY) ?: false
        set(value) = savedStateHandle.set(ANSWER_KEY, value)

    var currentIndex: Int get() = savedStateHandle.get(CURRENT_INDEX_KEY) ?: 0
        set(value) = savedStateHandle.set(CURRENT_INDEX_KEY, value)

    val currentQuestionAnswer: String get() = answersBank[currentIndex].answer

    val currentQuestionTextId: Int get() = currentIndex

    fun moveToNext() {
        currentIndex = (currentIndex + 1) % answersBank.size

    }

}
